<?php
print '<head>
	<title>Oval Office</title>
	<link type="text/css" href="css/custom-theme/jquery-ui-1.8.9.custom.css" rel="stylesheet" />	
	<script type="text/javascript" src="js/jquery-1.4.4.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.9.custom.min.js"></script>
	<script type="text/javascript" src="js/slimbox2.js"></script>
	<link rel="stylesheet" href="css/slimbox2.css" type="text/css" media="screen" />
	<link type="text/css" href="css/oo.css" rel="stylesheet" />
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
</head>
<body>
	<div id="header"><div id="logo"></div><div id="logout"><a href="#"></a></div>'.$town_name.' · Tag '.$c_day.'</div>
	<div id="container">';
	