﻿<?php

$translation = array(
	'day' => 'Tag',
	'by' => 'von',
	'Invalid user key!' => 'Der User-Key hat nicht die richtige Länge!',
	'Enter' => 'Eintreten',
);