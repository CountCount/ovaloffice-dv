<?php
#include_once 'cfg.php';
?>
<p>Um Einlass in das Oval Office zu erlangen, musst Du Dich zuerst identifizieren. Bitte nutze dazu das Verzeichnis im Spiel selbst (das kleine Buch-Icon oben links auf der Seite).</p>