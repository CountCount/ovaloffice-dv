<?php ?>
<div class="news"><strong>Aktuelles</strong>
				<p><span class="date">05.09.2011, 15:00 Uhr</span><br/>Ausgabe 33 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">28.08.2011, 23:40 Uhr</span><br/>Ausgabe 32 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">21.08.2011, 15:35 Uhr</span><br/>Ausgaben 30 + 31 von <em>Borderlands Bote</em> sind verfügbar</p>
				<p><span class="date">07.08.2011, 23:25 Uhr</span><br/>Ausgabe 29 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">31.07.2011, 13:30 Uhr</span><br/>Ausgabe 28 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">29.07.2011, 08:35 Uhr</span><br/>Ausgaben 26 + 27 von <em>Borderlands Bote</em> sind verfügbar</p>
				<p><span class="date">10.07.2011, 15:10 Uhr</span><br/>Ausgabe 25 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">07.07.2011, 14:30 Uhr</span><br/><span style="color:#0c0;">NEU:</span> Erweiterte Akteneinsicht für Bürger</p>
				<p><span class="date">04.07.2011, 00:40 Uhr</span><br/>Ausgabe 24 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">28.06.2011, 10:40 Uhr</span><br/><span style="color:#0c0;">NEU:</span> Akteneinsicht (Statistik)</p>
				<p><span class="date">27.06.2011, 09:00 Uhr</span><br/>Ausgabe 23 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">19.06.2011, 08:15 Uhr</span><br/>Ausgabe 22 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">14.06.2011, 12:00 Uhr</span><br/><span style="color:#0c0;">NEU:</span> Postamt startet seinen Dienst</p>
				<p><span class="date">12.06.2011, 01:00 Uhr</span><br/>Ausgabe 21 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">05.06.2011, 02:10 Uhr</span><br/>Ausgabe 20 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">01.06.2011, 12:30 Uhr</span><br/>Der Einsiedler ist da! Und hier. Mit Icon auch in der Karte und im Bürgeramt vertreten.</p>
				<p><span class="date">30.05.2011, 10:40 Uhr</span><br/>Ausgabe 19 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">24.05.2011, 09:30 Uhr</span><br/>Ausgabe 18 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">15.05.2011, 23:15 Uhr</span><br/>Ausgabe 17 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">12.05.2011, 13:45 Uhr</span><br/>Auswärtiges Amt: Suchergebnisse vorformatiert für das Stadtforum verfügbar</p>
				<p><span class="date">12.05.2011, 13:00 Uhr</span><br/>Auswärtiges Amt: Anzahl der Zombies als Zahlen zuschaltbar</p>
				<p><span class="date">12.05.2011, 12:00 Uhr</span><br/>Auswärtiges Amt: Überarbeitung Datenspeicherung, Unterscheidung von Aktualisierung und Besuch eines Feldes (OO 3.6)</p>
				<p><span class="date">12.05.2011, 11:00 Uhr</span><br/>Extended Toolbox Redesign (v2.3) mit ersten Funktionen</p>
				<p><span class="date">11.05.2011, 16:00 Uhr</span><br/>Extended Toolbox (Toolbox v2)</p>
				<p><span class="date">09.05.2011, 12:40 Uhr</span><br/>Auswärtiges Amt: die Suche funktioniert nun auch mit Kategorien</p>
				<p><span class="date">09.05.2011, 11:00 Uhr</span><br/>Ausgabe 16 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">06.05.2011, 14:40 Uhr</span><br/>Auswärtiges Amt bietet jetzt eine Suche nach Gegenständen auf der Karte (unter Kartenoptionen)</p>
				<p><span class="date">06.05.2011, 10:20 Uhr</span><br/>Stadtliste enthält nun die Anzahl an Kanistern in der Bank</p>
				<p><span class="date">01.05.2011, 20:45 Uhr</span><br/>Ausgabe 15 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">28.04.2011, 23:50 Uhr</span><br/><strong style="color:#00d;">Neues GREASEMONKEY Script: die OO Toolbox!</strong></p>
				<p><span class="date">27.04.2011, 08:45 Uhr</span><br/>Kartenoptionen in die neue Infobox verschoben</p>
				<p><span class="date">27.04.2011, 08:10 Uhr</span><br/>Keine Toten im Reisebüro</p>
				<p><span class="date">26.04.2011, 15:30 Uhr</span><br/>Ausgabe 14 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">24.04.2011, 22:45 Uhr</span><br/>OOsterhasenpärchen gekürt</p>
				<p><span class="date">20.04.2011, 01:45 Uhr</span><br/>Auswärtiges Amt: Neue Zoneninfo</p>
				<p><span class="date">18.04.2011, 14:15 Uhr</span><br/>Statistikamt: Erhältliche Titel eingebaut</p>
				<p><span class="date">18.04.2011, 11:30 Uhr</span><br/>Bauamt: AP-Berechnung in der Werkstatt korrigiert und zusätzliche Umwandlungsmethoden implementiert</p>
				<p><span class="date">18.04.2011, 11:00 Uhr</span><br/>Reisebüro: KP-Berechnung der Reisegruppen korrigiert</p>
				<p><span class="date">18.04.2011, 10:20 Uhr</span><br/>Statistikamt: Liste aktiver Städte enthält Anzahl überlebener Bürger</p>
				<p><span class="date">18.04.2011, 10:00 Uhr</span><br/>Registerauskunft im Bürgeramt ist eröffnet</p>
				<p><span class="date">17.04.2011, 18:30 Uhr</span><br/>Ausgabe 13 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">16.04.2011, 01:20 Uhr</span><br/>Datenbank auf neuen DB-Sever umgezogen, OO sollte wieder flüssig laufen</p>
				<p><span class="date">15.04.2011, 12:00 Uhr</span><br/>Beta von <em>Hau den Bürger</em> gestoppt auf Grund technischer Limitierungen</p>
				<p><span class="date">14.04.2011, 13:00 Uhr</span><br/>Erste öffentliche Beta von <em>Hau den Bürger</em> ist verfügbar</p>
				<p><span class="date">10.04.2011, 20:45 Uhr</span><br/>Ausgabe 12 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">06.04.2011, 13:30 Uhr</span><br/><strong>Todesrechner</strong> von <em>haase</em> eingebaut</p>
				<p><span class="date">05.04.2011, 00:35 Uhr</span><br/>Ausgabe 11 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">02.04.2011, 12:00 Uhr</span><br/><strong style="color:#00d;">GREASEMONKEY Support!</strong></p>
				<p><span class="date">01.04.2011, 14:30 Uhr</span><br/>Bürgeramt: Jeder Bürger kann sich eine Vorlage erstellen, die mittels einem Klick gespeichert bzw. geladen werden kann.</p>
				<p><span class="date">31.03.2011, 21:20 Uhr</span><br/>Auswärtiges Amt: Bürger in der Außenwelt werden als Punkte dargestellt</p>
				<p><span class="date">31.03.2011, 20:20 Uhr</span><br/>Statistikamt: Spalte für Deff-Items im Städtevergleich</p>
				<p><span class="date">31.03.2011, 12:30 Uhr</span><br/>Statistikamt: Top25 auf Top100 erweitert</p>
				<p><span class="date">31.03.2011, 11:00 Uhr</span><br/>Statistikamt: rudimentärer Städtevergleich</p>
				<p><span class="date">30.03.2011, 22:10 Uhr</span><br/>Bugfixes im Bauamt</p>
				<p><span class="date">29.03.2011, 15:00 Uhr</span><br/>Bauplaner v1.3: Werkstattarbeiten einbezogen</p>
				<p><span class="date">29.03.2011, 13:15 Uhr</span><br/><span style="color:#0c0;">NEU:</span> Bauplaner v1.2 implementiert</p>
				<p><span class="date">28.03.2011, 16:00 Uhr</span><br/><span style="color:#0c0;">NEU:</span> Bauamt verfügbar</p>
				<p><span class="date">28.03.2011, 10:00 Uhr</span><br/><span style="color:#0c0;">NEU:</span> IM Support (siehe Wartebereich)</p>
				<p><span class="date">27.03.2011, 22:00 Uhr</span><br/>Bugfixes Bürgeramt</p>
				<p><span class="date">25.03.2011, 18:30 Uhr</span><br/><span style="color:#c00;">Fehler im Auswärtigen Amt: Liste der Gegenstände auf der eigenen Zone wurden nicht aktualisiert. Zeitspanne des Fehlers: 24.03., 22:41 Uhr bis 25.03., 18:28 Uhr</span></p>
				<p><span class="date">21.03.2011, 22:30 Uhr</span><br/>Wartungsarbeiten: Neue Version des OO</p>
				<p><span class="date">21.03.2011, 13:00 Uhr</span><br/>Amt für Statistik: Register für Seelenauszeichnungen</p>
				<p><span class="date">21.03.2011, 08:30 Uhr</span><br/>Ausgabe 9 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">17.03.2011, 20:30 Uhr</span><br/>Auswärtiges Amt: Kleine Bugfixes an der Karte</p>
				<p><span class="date">14.03.2011, 17:15 Uhr</span><br/>Reisebüro: Voraussage zu Zombiezahlen und Gegenständen</p>
				<p><span class="date">14.03.2011, 16:30 Uhr</span><br/>Foyer: Wegweiser zu externen Gebäuden</p>
				<p><span class="date">14.03.2011, 12:40 Uhr</span><br/>Auswärtiges Amt: Bugfix an der Karte bzgl. Gegenstände am Boden</p>
				<p><span class="date">14.03.2011, 10:00 Uhr</span><br/>Amt für Statistik: Werte der eigenen Stadt werden mit angezeigt</p>
				<p><span class="date">14.03.2011, 09:40 Uhr</span><br/>Einwohnermeldeamt: Gespeicherte Werte werden nun geladen beim Ändern des Tages</p>
				<p><span class="date">13.03.2011, 23:30 Uhr</span><br/>Ausgabe 8 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">11.03.2011, 22:30 Uhr</span><br/>Finanzamt: Staubiges Buch</p>
				<p><span class="date">11.03.2011, 20:45 Uhr</span><br/>Neue Diagrammoption: Liniendiagramm</p>
				<p><span class="date">10.03.2011, 22:20 Uhr</span><br/>Finanzamt ebenfalls erweitert, weitere Übersichtsgrafiken</p>
				<p><span class="date">10.03.2011, 14:00 Uhr</span><br/>Statistikamt erweitert, Klick auf Tabellenzeile erzeugt Übersichtsgrafik</p>
				<p><span class="date">09.03.2011, 10:30 Uhr</span><br/>Reisebüro überarbeitet, bessere Sortierung, Anzeige aller Reisegruppen der Stadt</p>
				<p><span class="date">07.03.2011, 11:00 Uhr</span><br/>Kartenerzeugung verbessert, Generierungszeit auf 15% gesenkt</p>
				<p><span class="date">06.03.2011, 19:00 Uhr</span><br/>Ausgabe 7 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">04.03.2011, 18:00 Uhr</span><br/>Zurück von der CeBIT, Grippe im Schlepptau</p>
				<p><span class="date">27.02.2011, 21:00 Uhr</span><br/>Visuelle Berufsangabe im EMA</p>
				<p><span class="date">27.02.2011, 19:10 Uhr</span><br/>Ausgabe 6 von <em>Borderlands Bote</em> ist verfügbar</p>
				<p><span class="date">27.02.2011, 18:15 Uhr</span><br/>Erweiterung EMA um Zweite Lunge und Mehrfachdrogen</p>
				<p><span class="date">27.02.2011, 14:15 Uhr</span><br/>Reisebüro nimmt seinen (noch sehr einfachen) Dienst auf.</p>
				<p><span class="date">25.02.2011, 13:45 Uhr</span><br/>Wartung an den Kartenfunktionen</p>
				<p><span class="date">21.02.2011, 19:30 Uhr</span><br/>Aufnahme in das DV-Verzeichnis</p>
				<p><span class="date">20.02.2011, 18:00 Uhr</span><br/>Gegenstände in einer Zone werden gespeichert und ausgegeben</p>
				</div>